# Keep accessibility service & overlay classes
-keep class ru.wbhelper.courier.services.** { *; }
-keep class ru.wbhelper.courier.overlay.** { *; }
