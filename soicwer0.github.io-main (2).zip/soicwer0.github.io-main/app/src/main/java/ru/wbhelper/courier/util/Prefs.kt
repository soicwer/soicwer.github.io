package ru.wbhelper.courier.util

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import ru.wbhelper.courier.model.AppTheme
import ru.wbhelper.courier.model.Filters

class Prefs(ctx: Context) {
    private val sp: SharedPreferences =
        ctx.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    var filters: Filters
        get() = Filters(
            enabled = sp.getBoolean(K_ENABLED, false),
            testMode = sp.getBoolean(K_TEST, true),
            maxDistanceKm = sp.getFloat(K_DIST, 5f),
            maxWeightKg = sp.getFloat(K_WEIGHT, 50f),
            minPriceRub = sp.getFloat(K_PRICE, 100f),
            maxVolumeM3 = sp.getFloat(K_VOLUME, 1f),
            playSound = sp.getBoolean(K_SOUND, true),
            theme = AppTheme.fromId(sp.getInt(K_THEME, AppTheme.GLASS.id)),
        )
        set(v) = sp.edit {
            putBoolean(K_ENABLED, v.enabled)
            putBoolean(K_TEST, v.testMode)
            putFloat(K_DIST, v.maxDistanceKm)
            putFloat(K_WEIGHT, v.maxWeightKg)
            putFloat(K_PRICE, v.minPriceRub)
            putFloat(K_VOLUME, v.maxVolumeM3)
            putBoolean(K_SOUND, v.playSound)
            putInt(K_THEME, v.theme.id)
        }

    fun observe(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        sp.registerOnSharedPreferenceChangeListener(listener)
    }

    fun stopObserving(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        sp.unregisterOnSharedPreferenceChangeListener(listener)
    }

    companion object {
        private const val NAME = "wb_helper_prefs"
        private const val K_ENABLED = "enabled"
        private const val K_TEST = "test_mode"
        private const val K_DIST = "max_distance_km"
        private const val K_WEIGHT = "max_weight_kg"
        private const val K_PRICE = "min_price_rub"
        private const val K_VOLUME = "max_volume_m3"
        private const val K_SOUND = "play_sound"
        private const val K_THEME = "theme"
    }
}
