package ru.wbhelper.courier.ui

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.slider.Slider
import ru.wbhelper.courier.R
import ru.wbhelper.courier.databinding.ActivityMainBinding
import ru.wbhelper.courier.model.AppTheme
import ru.wbhelper.courier.overlay.OverlayService
import ru.wbhelper.courier.services.WBAccessibilityService
import ru.wbhelper.courier.util.Prefs

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = Prefs(this)
        applySelectedTheme(prefs.filters.theme)
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        bindThemeChips()
        bindSliders()
        bindSwitches()
        bindButtons()

        loadIntoUi()
    }

    override fun onResume() {
        super.onResume()
        b.tvAccessibilityStatus.text = getString(
            if (isAccessibilityEnabled()) R.string.status_acc_on else R.string.status_acc_off
        )
        b.tvOverlayStatus.text = getString(
            if (canOverlay()) R.string.status_ov_on else R.string.status_ov_off
        )
    }

    private fun applySelectedTheme(theme: AppTheme) {
        setTheme(
            when (theme) {
                AppTheme.LIGHT -> R.style.Theme_WBCourierHelper
                AppTheme.DARK -> R.style.Theme_WBCourierHelper_Dark
                AppTheme.GLASS -> R.style.Theme_WBCourierHelper_Glass
            }
        )
    }

    private fun bindThemeChips() {
        val current = prefs.filters.theme
        b.cgTheme.check(
            when (current) {
                AppTheme.LIGHT -> R.id.chipLight
                AppTheme.DARK -> R.id.chipDark
                AppTheme.GLASS -> R.id.chipGlass
            }
        )
        b.cgTheme.setOnCheckedStateChangeListener { _, ids ->
            val selected = when (ids.firstOrNull()) {
                R.id.chipLight -> AppTheme.LIGHT
                R.id.chipDark -> AppTheme.DARK
                R.id.chipGlass -> AppTheme.GLASS
                else -> current
            }
            if (selected != prefs.filters.theme) {
                prefs.filters = prefs.filters.copy(theme = selected)
                recreate()
            }
        }
    }

    private fun bindSwitches() {
        b.swEnabled.setOnCheckedChangeListener { _, on ->
            prefs.filters = prefs.filters.copy(enabled = on)
        }
        b.swTest.setOnCheckedChangeListener { _, on ->
            prefs.filters = prefs.filters.copy(testMode = on)
        }
        b.swSound.setOnCheckedChangeListener { _, on ->
            prefs.filters = prefs.filters.copy(playSound = on)
        }
    }

    private data class Row(val label: TextView, val value: TextView, val slider: Slider)

    private lateinit var rowDistance: Row
    private lateinit var rowWeight: Row
    private lateinit var rowPrice: Row
    private lateinit var rowVolume: Row

    private fun row(include: View) = Row(
        include.findViewById(R.id.tvLabel),
        include.findViewById(R.id.tvValue),
        include.findViewById(R.id.slider)
    )

    private fun bindSliders() {
        rowDistance = row(b.rowDistance.root).also { configure(it, getString(R.string.label_distance), 0f, 50f, 0.5f, getString(R.string.unit_km)) }
        rowWeight = row(b.rowWeight.root).also { configure(it, getString(R.string.label_weight), 0f, 200f, 1f, getString(R.string.unit_kg)) }
        rowPrice = row(b.rowPrice.root).also { configure(it, getString(R.string.label_price), 0f, 3000f, 10f, getString(R.string.unit_rub)) }
        rowVolume = row(b.rowVolume.root).also { configure(it, getString(R.string.label_volume), 0f, 5f, 0.05f, getString(R.string.unit_m3)) }

        rowDistance.slider.addOnChangeListener { _, v, _ -> updateValue(rowDistance, v, getString(R.string.unit_km)); prefs.filters = prefs.filters.copy(maxDistanceKm = v) }
        rowWeight.slider.addOnChangeListener   { _, v, _ -> updateValue(rowWeight,   v, getString(R.string.unit_kg)); prefs.filters = prefs.filters.copy(maxWeightKg   = v) }
        rowPrice.slider.addOnChangeListener    { _, v, _ -> updateValue(rowPrice,    v, getString(R.string.unit_rub), 0); prefs.filters = prefs.filters.copy(minPriceRub = v) }
        rowVolume.slider.addOnChangeListener   { _, v, _ -> updateValue(rowVolume,   v, getString(R.string.unit_m3)); prefs.filters = prefs.filters.copy(maxVolumeM3   = v) }
    }

    private fun configure(r: Row, label: String, from: Float, to: Float, step: Float, unit: String) {
        r.label.text = label
        r.slider.valueFrom = from
        r.slider.valueTo = to
        r.slider.stepSize = step
    }

    private fun updateValue(r: Row, v: Float, unit: String, decimals: Int = 1) {
        r.value.text = if (decimals == 0) "${v.toInt()} $unit" else "%.${decimals}f $unit".format(v)
    }

    private fun bindButtons() {
        b.btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        b.btnOverlayPermission.setOnClickListener {
            if (!canOverlay()) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } else {
                Toast.makeText(this, "Разрешение уже выдано", Toast.LENGTH_SHORT).show()
            }
        }
        b.btnStartOverlay.setOnClickListener {
            if (!canOverlay()) {
                Toast.makeText(this, R.string.err_overlay_perm, Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            startForegroundService(Intent(this, OverlayService::class.java))
        }
        b.btnStopOverlay.setOnClickListener {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        }
    }

    private fun loadIntoUi() {
        val f = prefs.filters
        b.swEnabled.isChecked = f.enabled
        b.swTest.isChecked = f.testMode
        b.swSound.isChecked = f.playSound

        rowDistance.slider.value = f.maxDistanceKm.coerceIn(rowDistance.slider.valueFrom, rowDistance.slider.valueTo)
        rowWeight.slider.value   = f.maxWeightKg.coerceIn(rowWeight.slider.valueFrom, rowWeight.slider.valueTo)
        rowPrice.slider.value    = f.minPriceRub.coerceIn(rowPrice.slider.valueFrom, rowPrice.slider.valueTo)
        rowVolume.slider.value   = f.maxVolumeM3.coerceIn(rowVolume.slider.valueFrom, rowVolume.slider.valueTo)

        updateValue(rowDistance, rowDistance.slider.value, getString(R.string.unit_km))
        updateValue(rowWeight,   rowWeight.slider.value,   getString(R.string.unit_kg))
        updateValue(rowPrice,    rowPrice.slider.value,    getString(R.string.unit_rub), 0)
        updateValue(rowVolume,   rowVolume.slider.value,   getString(R.string.unit_m3))
    }

    private fun canOverlay(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)

    private fun isAccessibilityEnabled(): Boolean {
        val expected = ComponentName(this, WBAccessibilityService::class.java).flattenToString()
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabled = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        if (enabled.any { it.id.contains(packageName) }) return true
        val setting = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(setting)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expected, ignoreCase = true)) return true
        }
        return false
    }
}
