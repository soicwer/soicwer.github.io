package ru.wbhelper.courier.util

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator

class SoundPlayer(ctx: Context) {
    private val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)

    fun beep() {
        tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 250)
    }

    fun release() {
        runCatching { tone.release() }
    }
}
