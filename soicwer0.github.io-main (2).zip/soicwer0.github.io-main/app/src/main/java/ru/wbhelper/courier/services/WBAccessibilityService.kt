package ru.wbhelper.courier.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import ru.wbhelper.courier.model.Filters
import ru.wbhelper.courier.util.OrderParser
import ru.wbhelper.courier.util.Prefs
import ru.wbhelper.courier.util.SoundPlayer
import java.util.concurrent.atomic.AtomicBoolean

class WBAccessibilityService : AccessibilityService() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var workerThread: HandlerThread
    private lateinit var worker: Handler
    private val running = AtomicBoolean(false)

    private lateinit var prefs: Prefs
    private var sound: SoundPlayer? = null

    private var lastProcessMs = 0L
    private var lastTapMs = 0L
    private var lastProcessedOrderId: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = Prefs(this)
        sound = SoundPlayer(this)
        workerThread = HandlerThread("WBHelperWorker").apply { start() }
        worker = Handler(workerThread.looper)
        Log.i(TAG, "Service connected")
    }

    override fun onDestroy() {
        super.onDestroy()
        sound?.release()
        if (::workerThread.isInitialized) workerThread.quitSafely()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val filters = try { prefs.filters } catch (_: Throwable) { return }
        if (!filters.enabled) return

        val now = System.currentTimeMillis()
        if (now - lastProcessMs < PROCESS_INTERVAL_MS) return
        if (!running.compareAndSet(false, true)) return
        lastProcessMs = now

        worker.post {
            try {
                val root = rootInActiveWindow ?: return@post
                handleScreen(root, filters)
            } catch (t: Throwable) {
                Log.e(TAG, "handleScreen failed", t)
            } finally {
                running.set(false)
            }
        }
    }

    private fun handleScreen(root: AccessibilityNodeInfo, f: Filters) {
        if (isOrderDetailScreen(root)) {
            handleOrderDetail(root, f)
            return
        }
        if (isMapScreen(root)) {
            handleMap(root)
        }
    }

    private fun isMapScreen(root: AccessibilityNodeInfo): Boolean =
        hasText(root, "Автоназначение") || hasText(root, "Геопозиция")

    private fun isOrderDetailScreen(root: AccessibilityNodeInfo): Boolean =
        hasText(root, "Забронировать") && hasText(root, "Доставки")

    private fun handleMap(root: AccessibilityNodeInfo) {
        if (System.currentTimeMillis() - lastTapMs < TAP_COOLDOWN_MS) return

        val auto = findClickable(root, "Автоназначение")
        if (auto != null) {
            performClickOrParent(auto)
            lastTapMs = System.currentTimeMillis()
        }
    }

    private fun handleOrderDetail(root: AccessibilityNodeInfo, f: Filters) {
        val blobs = collectTexts(root, MAX_TEXT_NODES)
        val info = OrderParser.parse(blobs)

        val orderId = info.orderId
        if (orderId != null && orderId == lastProcessedOrderId) return

        if (!info.matches(f)) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            return
        }

        if (f.playSound) mainHandler.post { sound?.beep() }

        if (f.testMode) {
            if (orderId != null) lastProcessedOrderId = orderId
            mainHandler.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, 1500)
            return
        }

        val slider = findClickable(root, "Забронировать")
        if (slider != null) {
            val r = Rect()
            slider.getBoundsInScreen(r)
            if (!r.isEmpty) {
                performSlideRight(r)
                if (orderId != null) lastProcessedOrderId = orderId
                lastTapMs = System.currentTimeMillis()
            }
        }
    }

    private fun performSlideRight(bounds: Rect) {
        val startX = (bounds.left + bounds.height() / 2).toFloat()
        val endX = (bounds.right - bounds.height() / 2).toFloat()
        val y = ((bounds.top + bounds.bottom) / 2).toFloat()
        val path = Path().apply {
            moveTo(startX, y)
            lineTo(endX, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 600L)
        mainHandler.post {
            dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
        }
    }

    private fun performClickOrParent(node: AccessibilityNodeInfo) {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 6) {
            if (n.isClickable) {
                val target = n
                mainHandler.post { target.performAction(AccessibilityNodeInfo.ACTION_CLICK) }
                return
            }
            n = n.parent
            depth++
        }
        val r = Rect()
        node.getBoundsInScreen(r)
        if (!r.isEmpty) {
            val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
            val stroke = GestureDescription.StrokeDescription(path, 0L, 50L)
            mainHandler.post {
                dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
            }
        }
    }

    private fun findClickable(root: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        val matches = root.findAccessibilityNodeInfosByText(text) ?: return null
        for (m in matches) {
            var n: AccessibilityNodeInfo? = m
            var d = 0
            while (n != null && d < 6) {
                if (n.isClickable) return n
                n = n.parent
                d++
            }
        }
        return matches.firstOrNull()
    }

    private fun hasText(root: AccessibilityNodeInfo, text: String): Boolean {
        val res = root.findAccessibilityNodeInfosByText(text)
        return !res.isNullOrEmpty()
    }

    private fun collectTexts(root: AccessibilityNodeInfo, limit: Int): List<String> {
        val out = ArrayList<String>(64)
        val q = ArrayDeque<AccessibilityNodeInfo>()
        q.add(root)
        var visited = 0
        while (q.isNotEmpty() && visited < limit) {
            val n = q.removeFirst()
            visited++
            n.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
            n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
            for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
        }
        return out
    }

    companion object {
        private const val TAG = "WBAccService"
        private const val TAP_COOLDOWN_MS = 1500L
        private const val PROCESS_INTERVAL_MS = 600L
        private const val MAX_TEXT_NODES = 400
    }
}
