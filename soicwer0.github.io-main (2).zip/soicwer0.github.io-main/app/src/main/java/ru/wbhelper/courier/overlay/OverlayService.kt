package ru.wbhelper.courier.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.materialswitch.MaterialSwitch
import ru.wbhelper.courier.R
import ru.wbhelper.courier.ui.MainActivity
import ru.wbhelper.courier.util.Prefs

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private lateinit var prefs: Prefs

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startInForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.err_overlay_perm, Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }

        showOverlay()
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        removeOverlay()
        showOverlay()
    }

    override fun onDestroy() {
        super.onDestroy()
        removeOverlay()
    }

    private fun showOverlay() {
        if (overlay != null) return

        val themed = ContextThemeWrapper(this, R.style.Theme_WBCourierHelper_Glass)
        val view = LayoutInflater.from(themed).inflate(R.layout.overlay_menu, null)

        val toggle = view.findViewById<MaterialSwitch>(R.id.swEnabled)
        val testToggle = view.findViewById<MaterialSwitch>(R.id.swTest)
        val status = view.findViewById<TextView>(R.id.tvStatus)
        val openSettings = view.findViewById<View>(R.id.btnSettings)
        val close = view.findViewById<View>(R.id.btnClose)
        val handle = view.findViewById<View>(R.id.dragHandle)

        val current = prefs.filters
        toggle.isChecked = current.enabled
        testToggle.isChecked = current.testMode
        updateStatus(status, current.enabled, current.testMode)

        toggle.setOnCheckedChangeListener { _, on ->
            prefs.filters = prefs.filters.copy(enabled = on)
            updateStatus(status, on, testToggle.isChecked)
        }
        testToggle.setOnCheckedChangeListener { _, on ->
            prefs.filters = prefs.filters.copy(testMode = on)
            updateStatus(status, toggle.isChecked, on)
        }
        openSettings.setOnClickListener {
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
        close.setOnClickListener { stopSelf() }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 200
        }

        attachDrag(handle, view, lp)

        try {
            wm.addView(view, lp)
            overlay = view
        } catch (t: Throwable) {
            Log.e(TAG, "addView failed", t)
            Toast.makeText(this, R.string.err_overlay_add, Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun attachDrag(handle: View, root: View, lp: WindowManager.LayoutParams) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        handle.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = ev.rawX
                    touchY = ev.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (ev.rawX - touchX).toInt()
                    lp.y = startY + (ev.rawY - touchY).toInt()
                    runCatching { wm.updateViewLayout(root, lp) }
                    true
                }
                else -> false
            }
        }
    }

    private fun updateStatus(tv: TextView, enabled: Boolean, test: Boolean) {
        tv.text = when {
            !enabled -> getString(R.string.status_off)
            test -> getString(R.string.status_on_test)
            else -> getString(R.string.status_on_live)
        }
    }

    private fun removeOverlay() {
        overlay?.let { runCatching { wm.removeView(it) } }
        overlay = null
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, getString(R.string.overlay_channel),
                NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(ch)
        }
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.overlay_title))
            .setContentText(getString(R.string.overlay_subtitle))
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    companion object {
        private const val TAG = "WBOverlay"
        const val ACTION_STOP = "ru.wbhelper.courier.STOP_OVERLAY"
        private const val CHANNEL_ID = "wb_overlay"
        private const val NOTIF_ID = 42
    }
}
