package ru.wbhelper.courier.model

enum class AppTheme(val id: Int) {
    LIGHT(0), DARK(1), GLASS(2);
    companion object {
        fun fromId(id: Int): AppTheme = entries.firstOrNull { it.id == id } ?: GLASS
    }
}

data class Filters(
    val enabled: Boolean = false,
    val testMode: Boolean = true,
    val maxDistanceKm: Float = 5f,
    val maxWeightKg: Float = 50f,
    val minPriceRub: Float = 100f,
    val maxVolumeM3: Float = 1f,
    val playSound: Boolean = true,
    val theme: AppTheme = AppTheme.GLASS,
)

data class OrderInfo(
    val priceRub: Float? = null,
    val bonusRub: Float? = null,
    val distanceKm: Float? = null,
    val weightKg: Float? = null,
    val volumeM3: Float? = null,
    val orderId: String? = null,
) {
    fun matches(f: Filters): Boolean {
        if ((distanceKm ?: 0f) > f.maxDistanceKm) return false
        if ((weightKg ?: 0f) > f.maxWeightKg) return false
        if ((priceRub ?: Float.MAX_VALUE) < f.minPriceRub) return false
        if ((volumeM3 ?: 0f) > f.maxVolumeM3) return false
        return true
    }
}
