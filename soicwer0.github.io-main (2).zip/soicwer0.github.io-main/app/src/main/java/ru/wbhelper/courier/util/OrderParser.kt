package ru.wbhelper.courier.util

import ru.wbhelper.courier.model.OrderInfo

object OrderParser {

    private val priceRegex = Regex("""(\d+[\s ]?\d*)\s*[₽Рр]""")
    private val distanceRegex = Regex("""(\d+[.,]?\d*)\s*(км|KM|km)""", RegexOption.IGNORE_CASE)
    private val weightRegex = Regex("""(\d+[.,]?\d*)\s*(кг|KG|kg)""", RegexOption.IGNORE_CASE)
    private val volumeRegex = Regex("""(\d+[.,]?\d*)\s*(м[³3]|M[³3]|m[³3])""", RegexOption.IGNORE_CASE)
    private val orderIdRegex = Regex("""№\s*(\d{6,})""")

    fun parse(textBlobs: List<String>): OrderInfo {
        val merged = textBlobs.joinToString(" ")
            .replace(' ', ' ')
            .replace(',', '.')
        return OrderInfo(
            priceRub = priceRegex.findAll(merged)
                .map { it.groupValues[1].replace(" ", "").toFloatOrNull() }
                .filterNotNull()
                .firstOrNull(),
            distanceKm = distanceRegex.find(merged)?.groupValues?.get(1)?.toFloatOrNull(),
            weightKg = weightRegex.find(merged)?.groupValues?.get(1)?.toFloatOrNull(),
            volumeM3 = volumeRegex.find(merged)?.groupValues?.get(1)?.toFloatOrNull(),
            orderId = orderIdRegex.find(merged)?.groupValues?.get(1),
        )
    }
}
